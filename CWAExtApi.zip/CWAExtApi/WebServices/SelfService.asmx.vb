﻿Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.ComponentModel

' To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
' <System.Web.Script.Services.ScriptService()> _
<System.Web.Services.WebService(Namespace:="http://tempuri.org/")> _
<System.Web.Services.WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)>
<ToolboxItem(False)>
Public Class SelfServiceInterface
    Inherits System.Web.Services.WebService

    Dim zodiacController As RestSharpZodiacController

    <WebMethod(Description:="Inquire draft invoice web method. Accepts draft invoice no, returns JSON output.")>
    Public Function InquireDraftInvoice(draftInvoiceNo As String, zUserId As String, zPassword As String, zPartyId As String) As String

        Dim returnJsonString As String = ""

        Try

            zodiacController = New RestSharpZodiacController
            returnJsonString = zodiacController.selfServiceInquireDraftInvoice(Utils.CleanString(draftInvoiceNo),
                                                                            Utils.CleanString(zUserId),
                                                                            Utils.CleanString(zPassword),
                                                                            Utils.CleanString(zPartyId))

            Return returnJsonString
            Global_asax.logger.Info(returnJsonString)

        Catch ex As Exception
            returnJsonString = ex.ToString
            Global_asax.logger.Error(ex.Message, ex)
        End Try

        Return returnJsonString
    End Function


    <WebMethod(Description:="Create quotation web method. Accepts: containerIdList must be separated by pipeline symbol, opAccountNo refers to EBS Customer Optr Account No, currency must be USD or SHL, payThroughDate refers to pickup date. Returns JSON output.")>
    Public Function CreateQuotation(containerIdList As String, opAccountNo As String, currency As String, payThroughDate As String,
                                    zPartyId As String, zUserId As String, zPassword As String) As String

        Dim returnJsonString As String = ""

        Try

            zodiacController = New RestSharpZodiacController
            returnJsonString = zodiacController.selfServiceCreateQuotation(Utils.CleanString(containerIdList).Split("|"),
                                                                           Utils.CleanString(opAccountNo),
                                                                           Utils.CleanString(currency), Utils.CleanString(payThroughDate),
                                                                           Utils.CleanString(zUserId),
                                                                           Utils.CleanString(zPassword), Utils.CleanString(zPartyId))

            Return returnJsonString
            Global_asax.logger.Info(returnJsonString)

        Catch ex As Exception
            returnJsonString = ex.ToString
            Global_asax.logger.Error(ex.Message, ex)
        End Try

        Return returnJsonString
    End Function


    <WebMethod(Description:="Create draft invoice web method. Accepts: quotationNumber. Returns JSON output.")>
    Public Function CreateDraftInvoice(quotationNumber As String, zUserId As String, zPassword As String, zPartyId As String) As String
        Dim returnJsonString As String = ""

        Try

            zodiacController = New RestSharpZodiacController
            returnJsonString = zodiacController.selfServiceCreateDraftInvoice(Utils.CleanString(quotationNumber),
                                                                     Utils.CleanString(zUserId),
                                                               Utils.CleanString(zPassword),
                                                               Utils.CleanString(zPartyId))

            Return returnJsonString
            Global_asax.logger.Info(returnJsonString)

        Catch ex As Exception
            returnJsonString = ex.ToString
            Global_asax.logger.Error(ex.Message, ex)
        End Try

        Return returnJsonString

    End Function


    <WebMethod(Description:="Create final invoice web method. Accepts: draftInvoiceNumber. Returns JSON output.")>
    Public Function CreateFinalInvoice(draftInvoiceNumber As String, zUserId As String, zPassword As String, zPartyId As String) As String

        Dim returnJsonString As String = ""

        Try

            zodiacController = New RestSharpZodiacController
            returnJsonString = zodiacController.selfServiceCreateFinalInvoice(Utils.CleanString(draftInvoiceNumber),
                                                                        Utils.CleanString(zUserId),
                                                                        Utils.CleanString(zPassword),
                                                                        Utils.CleanString(zPartyId))

            Return returnJsonString
            Global_asax.logger.Info(returnJsonString)

        Catch ex As Exception
            returnJsonString = ex.ToString
            Global_asax.logger.Error(ex.Message, ex)
        End Try

        Return returnJsonString
    End Function


End Class