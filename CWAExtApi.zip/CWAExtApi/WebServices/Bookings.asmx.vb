﻿Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.ComponentModel

' To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
' <System.Web.Script.Services.ScriptService()> _
<System.Web.Services.WebService(Namespace:="http://tempuri.org/")> _
<System.Web.Services.WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
<ToolboxItem(False)> _
Public Class Bookings
    Inherits System.Web.Services.WebService

    <WebMethod(Description:="Post import delivery order. Container list must be separated by pipeline symbol. updateMode values accepted are: new, revalidate, replace, cancel. Returns XML output.")>
    Public Function PostLinerImportDeliveryOrder(zPartyId As String, zUserId As String, zPassword As String,
                                                 docNo As String, docType As String, docPrepDate As String,
                                                 docExpireDate As String, bolNum As String, boxLine As String,
                                                 containerListPipeLine As String, updateMode As String) As String
        Dim returnXMLString As String = ""

        Try

            Dim releaseOrder As New ReleaseOrders
            Dim retmsg As DataTable
            Dim returnXMLWriter As New System.IO.StringWriter
            retmsg = releaseOrder.postLinerImportDeliveryOrder(Utils.CleanString(zPartyId),
                                                               Utils.CleanString(zUserId),
                                                               Utils.CleanString(zPassword),
                                                               Utils.CleanString(docNo),
                                                               Utils.CleanString(docType),
                                                               Utils.CleanString(docPrepDate),
                                                               Utils.CleanString(docExpireDate),
                                                               Utils.CleanString(bolNum),
                                                               Utils.CleanString(boxLine),
                                                               Utils.CleanString(containerListPipeLine).Split("|"),
                                                               Utils.CleanString(updateMode))

            retmsg.TableName = "PostLinerImportDeliveryOrder"
            retmsg.WriteXml(returnXMLWriter, XmlWriteMode.IgnoreSchema, False)

            returnXMLString = returnXMLWriter.ToString

            releaseOrder = Nothing
            retmsg = Nothing
            returnXMLWriter = Nothing
            Global_asax.logger.Info(returnXMLString)

        Catch ex As Exception
            returnXMLString = ex.ToString
            Global_asax.logger.Error(ex.Message, ex)
        End Try

        Return returnXMLString
    End Function


    <WebMethod(Description:="Get audit history for DO updates / changes to this BOL. Returns XML output.")>
    Public Function GetAuditImportDeliveryOrder(zPartyId As String, zUserId As String,
                                                zPassword As String, bol As String, boxLine As String) As String

        Dim releaseOrder As New ReleaseOrders
        Dim returnXMLString As String = ""
        Dim retmsg As DataTable

        Try

            Dim returnXMLWriter As New System.IO.StringWriter
            retmsg = releaseOrder.getAuditBOL(Utils.CleanString(bol))
            retmsg.WriteXml(returnXMLWriter, XmlWriteMode.IgnoreSchema, False)
            returnXMLString = returnXMLWriter.ToString

            releaseOrder = Nothing
            retmsg = Nothing
            returnXMLWriter = Nothing

            Global_asax.logger.Info(returnXMLString)

        Catch ex As Exception
            returnXMLString = ex.ToString
            Global_asax.logger.Error(ex.Message, ex)
        End Try

        Return returnXMLString

    End Function

End Class