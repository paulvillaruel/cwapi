﻿Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.ComponentModel

' To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
' <System.Web.Script.Services.ScriptService()> _
<System.Web.Services.WebService(Namespace:="http://tempuri.org/")> _
<System.Web.Services.WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
<ToolboxItem(False)> _
Public Class TruckActivity
    Inherits System.Web.Services.WebService

    <WebMethod(Description:="Gets VBS truck visit details, returns XML.")>
    Public Function GetTruckVisitDetails(truckPlateNo As String, bookingReference As String) As String
        Dim returnXMLString As String = ""

        Try

            Dim truckActivity As New TruckActivityController
            Dim retmsg As DataTable
            Dim returnXMLWriter As New System.IO.StringWriter
            retmsg = truckActivity.getTruckVisitDetails(Utils.CleanString(truckPlateNo),
                                                               Utils.CleanString(bookingReference))

            retmsg.TableName = "GetTruckVisitDetails"
            retmsg.WriteXml(returnXMLWriter, XmlWriteMode.IgnoreSchema, False)

            returnXMLString = returnXMLWriter.ToString

            truckActivity = Nothing
            retmsg = Nothing
            returnXMLWriter = Nothing
            Global_asax.logger.Info(returnXMLString)

        Catch ex As Exception
            returnXMLString = ex.ToString
            Global_asax.logger.Error(ex.Message, ex)
        End Try

        Return returnXMLString
    End Function


    <WebMethod(Description:="Saves VBS truck activity, returns XML.")>
    Public Function SaveTruckActivity(truckPlateNo As String, bookingReference As String,
                                      activityCode As String, visitReference As String,
                                      batNo As String, gateCode As String, laneNo As String) As String

        Dim returnXMLString As String = ""

        Try

            Dim truckActivity As New TruckActivityController
            Dim retmsg As DataTable
            Dim returnXMLWriter As New System.IO.StringWriter
            retmsg = truckActivity.saveTruckActivity(Utils.CleanString(truckPlateNo),
                                                        Utils.CleanString(bookingReference),
                                                        Utils.CleanString(activityCode),
                                                        Utils.CleanString(visitReference),
                                                        Utils.CleanString(batNo),
                                                        Utils.CleanString(gateCode),
                                                        Utils.CleanString(laneNo))

            retmsg.TableName = "SaveTruckActivity"
            retmsg.WriteXml(returnXMLWriter, XmlWriteMode.IgnoreSchema, False)

            returnXMLString = returnXMLWriter.ToString

            truckActivity = Nothing
            retmsg = Nothing
            returnXMLWriter = Nothing
            Global_asax.logger.Info(returnXMLString)

        Catch ex As Exception
            returnXMLString = ex.ToString
            Global_asax.logger.Error(ex.Message, ex)
        End Try

        Return returnXMLString
    End Function


    <WebMethod(Description:="Cancels VBS truck activity, returns XML.")>
    Public Function CancelTruckActivity(truckPlateNo As String, bookingReference As String,
                                      activityCode As String) As String

        Dim returnXMLString As String = ""

        Try

            Dim truckActivity As New TruckActivityController
            Dim retmsg As DataTable
            Dim returnXMLWriter As New System.IO.StringWriter
            retmsg = truckActivity.cancelTruckActivity(Utils.CleanString(truckPlateNo),
                                                        Utils.CleanString(bookingReference),
                                                        Utils.CleanString(activityCode))

            retmsg.TableName = "CancelTruckActivity"
            retmsg.WriteXml(returnXMLWriter, XmlWriteMode.IgnoreSchema, False)

            returnXMLString = returnXMLWriter.ToString

            truckActivity = Nothing
            retmsg = Nothing
            returnXMLWriter = Nothing
            Global_asax.logger.Info(returnXMLString)

        Catch ex As Exception
            returnXMLString = ex.ToString
            Global_asax.logger.Error(ex.Message, ex)
        End Try

        Return returnXMLString
    End Function


End Class