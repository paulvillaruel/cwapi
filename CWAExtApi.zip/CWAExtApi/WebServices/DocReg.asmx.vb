﻿Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.ComponentModel

' To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
' <System.Web.Script.Services.ScriptService()> _
<System.Web.Services.WebService(Namespace:="http://tempuri.org/")> _
<System.Web.Services.WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)>
<ToolboxItem(False)>
Public Class DocReg
    Inherits System.Web.Services.WebService

    Dim zodiacController As RestSharpZodiacController

    <WebMethod(Description:="Document registration inquiry by reference number. Returns JSON output.")>
    Public Function InquiryByReference(documentRegistrationNo As String, zUserId As String, zPassword As String, zPartyId As String) As String
        Dim returnJsonString As String = ""

        Try

            zodiacController = New RestSharpZodiacController
            returnJsonString = zodiacController.docRegInquireReference(Utils.CleanString(documentRegistrationNo),
                                                                            Utils.CleanString(zUserId),
                                                                            Utils.CleanString(zPassword),
                                                                            Utils.CleanString(zPartyId))

            Return returnJsonString
            Global_asax.logger.Info(returnJsonString)

        Catch ex As Exception
            returnJsonString = ex.ToString
            Global_asax.logger.Error(ex.Message, ex)
        End Try

        Return returnJsonString
    End Function


    <WebMethod(Description:="Document registration create reference. Returns json string response message.")>
    Public Function CreateReference(
                                   vesselVisitCode As String,
                                   billToCode As String,
                                   containerIdList As String,
                                   docValidDate As String,
                                   bolNumber As String,
                                   destinationLocationCode As String,
                                   doNumber As String,
                                   remarks As String,
                                   zUserId As String, zPassword As String, zPartyId As String) As String

        Dim returnMessage As String

        Try

            zodiacController = New RestSharpZodiacController
            returnMessage = zodiacController.docRegCreate(
                                    Utils.CleanString(vesselVisitCode),
                                    Utils.CleanString(billToCode),
                                    Utils.CleanString(containerIdList).Split("|"),
                                    Utils.CleanString(docValidDate),
                                    Utils.CleanString(bolNumber),
                                    Utils.CleanString(destinationLocationCode),
                                    Utils.CleanString(doNumber),
                                    Utils.CleanString(remarks),
                                    Utils.CleanString(zUserId),
                                    Utils.CleanString(zPassword),
                                    Utils.CleanString(zPartyId))

            Global_asax.logger.Info("Create Reference: Success")

        Catch ex As Exception
            returnMessage = Nothing
            Global_asax.logger.Error(ex.Message, ex)
        End Try

        Return returnMessage

    End Function


    <WebMethod(Description:="Document registration update pick-up date. Returns json string.")>
    Public Function UpdateValidityDate(
                                   documentRegistrationNo As String,
                                   documentValidityDate As String,
                                   zUserId As String, zPassword As String, zPartyId As String) As String

        Dim returnMessage As String

        Try

            zodiacController = New RestSharpZodiacController
            returnMessage = zodiacController.docRegUpdateValidityDate(
                                    Utils.CleanString(documentRegistrationNo),
                                    Utils.CleanString(documentValidityDate),
                                    Utils.CleanString(zUserId),
                                    Utils.CleanString(zPassword),
                                    Utils.CleanString(zPartyId))

            Global_asax.logger.Info("Update Validity Date: Success")

        Catch ex As Exception
            returnMessage = Nothing
            Global_asax.logger.Error(ex.Message, ex)
        End Try

        Return returnMessage

    End Function


End Class