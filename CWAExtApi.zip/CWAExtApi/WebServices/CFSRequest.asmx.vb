﻿Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.ComponentModel

' To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
' <System.Web.Script.Services.ScriptService()> _
<System.Web.Services.WebService(Namespace:="http://tempuri.org/")> _
<System.Web.Services.WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
<ToolboxItem(False)> _
Public Class CFSRequest
    Inherits System.Web.Services.WebService

    Dim zodiacController As RestSharpZodiacController



    <WebMethod(Description:="CFS inquiry by reference number. Returns JSON output.")>
    Public Function InquiryByReference(cfsRequestNo As String, zUserId As String, zPassword As String, zPartyId As String) As String
        Dim returnJsonString As String = ""

        Try

            zodiacController = New RestSharpZodiacController
            returnJsonString = zodiacController.cfsInquireReference(Utils.CleanString(cfsRequestNo),
                                                                            Utils.CleanString(zUserId),
                                                                            Utils.CleanString(zPassword),
                                                                            Utils.CleanString(zPartyId))

            Return returnJsonString
            Global_asax.logger.Info(returnJsonString)

        Catch ex As Exception
            returnJsonString = ex.ToString
            Global_asax.logger.Error(ex.Message, ex)
        End Try

        Return returnJsonString
    End Function


    <WebMethod(Description:="CFS request create reference. Returns json string response message.")>
    Public Function CreateReference(
                                   billToCode As String,
                                   requestDate As String,
                                   deadlineDate As String,
                                   requestNbr As String,
                                   doNumber As String,
                                   targetLocationCode As String,
                                   truckingCompanyCode As String,
                                   vesselVisitCode As String,
                                   notificationEmails As String, remarks As String,
                                   bolNumber As String,
                                   containerIdList As String,
                                   customBookingNo As String,
                                   cfsCheTypeCode As String,
                                   zUserId As String, zPassword As String, zPartyId As String) As String

        Dim returnMessage As String

        Try

            zodiacController = New RestSharpZodiacController
            returnMessage = zodiacController.cfsCreate(
                                    Utils.CleanString(billToCode),
                                    Utils.CleanString(requestDate),
                                    Utils.CleanString(deadlineDate),
                                    Utils.CleanString(requestNbr),
                                    Utils.CleanString(doNumber),
                                    Utils.CleanString(targetLocationCode),
                                    Utils.CleanString(truckingCompanyCode),
                                    Utils.CleanString(vesselVisitCode),
                                    Utils.CleanString(notificationEmails),
                                    Utils.CleanString(remarks),
                                    Utils.CleanString(bolNumber),
                                    Utils.CleanString(containerIdList).Split("|"),
                                    Utils.CleanString(customBookingNo),
                                    Utils.CleanString(cfsCheTypeCode),
                                    Utils.CleanString(zUserId),
                                    Utils.CleanString(zPassword),
                                    Utils.CleanString(zPartyId))

            Global_asax.logger.Info("Create Reference: Success")

        Catch ex As Exception
            returnMessage = Nothing
            Global_asax.logger.Error(ex.Message, ex)
        End Try

        Return returnMessage

    End Function


    <WebMethod(Description:="CFS request update pick-up date. Returns json string.")>
    Public Function UpdateValidityDate(
                                   cfsRequestNo As String,
                                   cfsRequestValidityDate As String,
                                   zUserId As String, zPassword As String, zPartyId As String) As String

        Dim returnMessage As String

        Try

            zodiacController = New RestSharpZodiacController
            returnMessage = zodiacController.cfsUpdateValidityDate(
                                    Utils.CleanString(cfsRequestNo),
                                    Utils.CleanString(cfsRequestValidityDate),
                                    Utils.CleanString(zUserId),
                                    Utils.CleanString(zPassword),
                                    Utils.CleanString(zPartyId))

            Global_asax.logger.Info("Update Validity Date: Success")

        Catch ex As Exception
            returnMessage = Nothing
            Global_asax.logger.Error(ex.Message, ex)
        End Try

        Return returnMessage

    End Function


End Class