﻿Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.ComponentModel

' To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
' <System.Web.Script.Services.ScriptService()> _
<System.Web.Services.WebService(Namespace:="http://tempuri.org/")> _
<System.Web.Services.WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
<ToolboxItem(False)> _
Public Class Weather
    Inherits System.Web.Services.WebService

    <WebMethod(Description:="Get current weather station (Weatherlink) reading. Returns JSON output.")>
    Public Function GetCurrentObservation() As String

        Dim weather As New WeatherController
        Return weather.getCurrentWeatherReading()

    End Function

End Class