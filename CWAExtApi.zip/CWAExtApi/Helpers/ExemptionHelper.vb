﻿Public Class ExemptionHelper

    Dim integrationController As New IntegrationController

    Public Function returnExemption(exemptionId As String) As System.Data.DataTable
        If exemptionId.Length > 0 Then
            integrationController.getConnectionString("cwa")
            Return integrationController.getTable("getExemptionDetails", CommandType.StoredProcedure,
                                           New SqlClient.SqlParameter("@exemptionId", exemptionId))
        End If
    End Function



End Class
