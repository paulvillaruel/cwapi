﻿Public Class Logger

End Class
