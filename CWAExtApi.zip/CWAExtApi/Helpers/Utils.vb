﻿Imports System.IO
Imports System.Xml
Imports Newtonsoft.Json

Public Class Utils

    Public Function convertDateTime(dateInput As String, formatInput As String) As String
        Try
            Dim dateValue As Date
            dateValue = Date.Parse(dateInput)
            Return dateValue.ToString(formatInput)
        Catch ex As Exception
            Global_asax.logger.Error("Invalid date. Parameters: " & "{dateInput, formatInput}, Values: " &
                                                      "{" & dateInput & "," & formatInput & "}", ex)

        End Try
    End Function

    Public Function readDataFromJson(ByVal jsonString As String, ByVal Optional mode As XmlReadMode = XmlReadMode.Auto) As DataSet
        jsonString = "{ ""rootNode"": {" & jsonString.Trim().TrimStart("{"c).TrimEnd("}"c) & "} }"
        Dim xd = JsonConvert.DeserializeXmlNode(jsonString)
        Dim result = New DataSet()
        result.ReadXml(New XmlNodeReader(xd), mode)
        Return result
    End Function


    Public Shared Function CleanString(ByVal dirtyString As String) As String
        Dim removeChars As HashSet(Of Char) = New HashSet(Of Char)(" ?&^$#@!(),;<>’'_*") ' I included here: , : | -
        Dim result As StringBuilder = New StringBuilder(dirtyString.Length)

        For Each c As Char In dirtyString
            If Not removeChars.Contains(c) Then result.Append(c)
        Next

        Return result.ToString()
    End Function


    Public Function readFile(fileName As String) As String
        Try
            Dim reader As IO.StreamReader = File.OpenText(fileName)
            Dim messageTemplate As String = reader.ReadToEnd()
            Return messageTemplate
        Catch ex As Exception
        End Try
    End Function


End Class
