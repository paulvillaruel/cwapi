﻿Imports SMTPMailer.SMTPMailer

Public Class EmailController

    Public Enum EmailTypes
        DO_UPDATE
        GENERIC
    End Enum

    Public Function IsEmailEnabled() As Boolean
        Return CBool(ConfigurationManager.AppSettings("smtpEnable"))
    End Function

    Public Function SendEmail(emailType As EmailTypes, recipients() As String,
                              details() As String,
                              Optional ByVal attachmentFileNames As String() = Nothing) As Boolean

        Dim notifyEnabled As Boolean = False
        notifyEnabled = CBool(ConfigurationManager.AppSettings("smtpEnable"))
        Dim util As New Utils


        If notifyEnabled Then

            Dim smtpEmail As New SMTPMailer.SMTPMailer
            Dim sFromAddress As String = ""
            Dim sBodyMsg As String = ""
            Dim sBodyFooter As String = ""
            Dim sSubject As String = ""
            Dim files As String()
            Dim fileExtension As String = ""
            Dim localPath As String = ""
            Dim mailtemplateFile As String = ""

            smtpEmail.SMTPUseDefaultCredentials = False
            smtpEmail.SMTPHost = ConfigurationManager.AppSettings("smtpHost").ToString()
            smtpEmail.SMTPPort = ConfigurationManager.AppSettings("smtpPort").ToString()
            smtpEmail.SMTPuser = ConfigurationManager.AppSettings("smtpUser").ToString()
            smtpEmail.SMTPPassword = ConfigurationManager.AppSettings("smtpPassword").ToString()
            smtpEmail.SMTPEnableSSL = ConfigurationManager.AppSettings("smtpEnableSSL").ToString()
            sFromAddress = ConfigurationManager.AppSettings("smtpMailFromAddress").ToString()

            Select Case emailType
                Case EmailTypes.DO_UPDATE

                    mailtemplateFile = ConfigurationManager.AppSettings("smtpMailBodyTemplatePath").ToString() &
                        ConfigurationManager.AppSettings("smtpMailTemplateDOUpdate").ToString()

                    sSubject = "DO Update notification BOL: " & details(1)

                    sBodyMsg = util.readFile(mailtemplateFile)
                    sBodyMsg = sBodyMsg.Replace("@updateType", details(0))
                    sBodyMsg = sBodyMsg.Replace("@billOfLading", details(1))
                    sBodyMsg = sBodyMsg.Replace("@containerList", details(2))
                    sBodyMsg = sBodyMsg.Replace("@doNumber", details(3))
                    sBodyMsg = sBodyMsg.Replace("@doValidity", details(4))

                Case EmailTypes.GENERIC

                    mailtemplateFile = ConfigurationManager.AppSettings("smtpMailBodyTemplatePath").ToString() &
                        ConfigurationManager.AppSettings("smtpMailTemplateDOUpdate").ToString()

                    sBodyMsg = util.readFile(mailtemplateFile)
                    sBodyMsg = sBodyMsg.Replace("@activityType", details(0))
                    sBodyMsg = sBodyMsg.Replace("@result", details(1))
                    sBodyMsg = sBodyMsg.Replace("@datetime", details(2))
                    sBodyMsg = sBodyMsg.Replace("@reference", details(3))
                    sBodyMsg = sBodyMsg.Replace("@details", details(3))

            End Select

            If Not attachmentFileNames Is Nothing Then
                If attachmentFileNames.Length > 0 Then
                    files = attachmentFileNames
                Else
                    files = Nothing
                End If
            Else
                files = Nothing
            End If

            sBodyFooter = "Timestamp: " & DateTime.Now.ToString & " at " & Environment.MachineName
            sBodyMsg = sBodyMsg & "<br/><br/>" & sBodyFooter

            smtpEmail.SendEmailMessage(sFromAddress, recipients, sSubject, sBodyMsg, files)
            Global_asax.logger.Info("SMTP notification successful.")

            Return True

        Else
            Global_asax.logger.Info("SMTP notification turned off.")
            Return True
        End If

    End Function




End Class
