﻿Imports System.Data
Imports System.Text.RegularExpressions
Imports System.Configuration
Imports System.Data.SqlClient

Public Class TruckActivityController

    '
    ' Author: Paul Jeremy N Villaruel
    ' Date: 14-Dec-2019
    ' Assumption: Integration with Zodiac is unavailable
    '

    Private integrationController As New IntegrationController


    '
    ' Get Truck Visit Details
    '
    Public Function getTruckVisitDetails(truckPlateNo As String, bookingReference As String) As DataTable

        Dim returnDetails As New DataTable

        If truckPlateNo.Length > 0 Or bookingReference.Length > 0 Then
            integrationController.getConnectionString("vbs")
            returnDetails = integrationController.getTable("GetTruckDetails", CommandType.StoredProcedure,
                                                           New SqlParameter("@truckPlateNo", truckPlateNo),
                                                           New SqlParameter("@bookingReference", bookingReference))
        Else
            returnDetails = returnErrorAsDataTable("Plate No or Booking Reference is required.")
        End If

        returnDetails.TableName = "getTruckVisitDetails"
        Return returnDetails

    End Function

    '
    'Save Truck Activity
    '

    Public Function saveTruckActivity(truckPlateNo As String, bookingReference As String, activityCode As String,
                                      visitReference As String, batNo As String, gateCode As String, laneNo As String) As DataTable

        Dim returnDetails As New DataTable

        If truckPlateNo.Length > 0 Or bookingReference.Length > 0 Or activityCode.Length > 0 Then
            integrationController.getConnectionString("vbs")
            returnDetails = integrationController.getTable("SaveTruckActivity", CommandType.StoredProcedure,
                                                           New SqlParameter("@truckPlateNo", truckPlateNo),
                                                           New SqlParameter("@bookingReference", bookingReference),
                                                           New SqlParameter("@activityCode", activityCode),
                                                           New SqlParameter("@visitReference", visitReference),
                                                           New SqlParameter("@batNo", batNo),
                                                           New SqlParameter("@gateCode", gateCode),
                                                           New SqlParameter("@laneNo", laneNo))
        Else
            returnDetails = returnErrorAsDataTable("Plate No or Booking Reference and activity code are required.")
        End If

        returnDetails.TableName = "saveTruckActivity"
        Return returnDetails

    End Function


    '
    ' Cancel truck activity
    '

    Public Function cancelTruckActivity(truckPlateNo As String, bookingReference As String, activityCode As String) As DataTable

        Dim returnDetails As New DataTable

        If truckPlateNo.Length > 0 Or bookingReference.Length > 0 Or activityCode.Length > 0 Then
            integrationController.getConnectionString("vbs")
            returnDetails = integrationController.getTable("CancelTruckActivity", CommandType.StoredProcedure,
                                                           New SqlParameter("@truckPlateNo", truckPlateNo),
                                                           New SqlParameter("@bookingReference", bookingReference),
                                                           New SqlParameter("@activityCode", activityCode))
        Else
            returnDetails = returnErrorAsDataTable("Plate No or Booking Reference and activity code are required.")
        End If

        returnDetails.TableName = "cancelTruckActivity"
        Return returnDetails

    End Function



    Public Function returnErrorAsDataTable(retMsg As String) As DataTable

        Dim dataTableError As New DataTable
        dataTableError.Columns.Add("retmsg")
        dataTableError.Rows.Add(retMsg)
        Return dataTableError

    End Function

End Class
