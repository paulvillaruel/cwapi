﻿Imports RestSharp
Imports Newtonsoft
Imports Newtonsoft.Json

Public Class WeatherController

    Public Function getCurrentWeatherReading() As String

        Try

            Dim url As String = ConfigurationManager.AppSettings("weatherLinkURL")
            Dim user As String = ConfigurationManager.AppSettings("weatherUser")
            Dim password As String = ConfigurationManager.AppSettings("weatherPassword")
            Dim token As String = ConfigurationManager.AppSettings("weatherAPIToken")
            Dim requestURL As String = String.Concat(url, "?user=", user, "&pass=", password, "&apiToken=", token)

            Dim returnMessage As String = ""

            Dim client = New RestClient(requestURL)
            Dim request = New RestRequest(Method.GET)
            request.AddHeader("cache-control", "no-cache")
            Dim response As IRestResponse = client.Execute(request)

            returnMessage = response.Content

            Global_asax.logger.Info(String.Concat("RequestURL: ", requestURL, " Response: ", returnMessage))

            Return returnMessage

        Catch ex As Exception
            Global_asax.logger.Fatal("Weather link API failed to return weather data.", ex)
            Throw ex
        End Try



    End Function


End Class
