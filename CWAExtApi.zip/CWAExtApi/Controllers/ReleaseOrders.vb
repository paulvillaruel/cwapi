﻿Imports System.Data
Imports RestSharp
Imports Newtonsoft
Imports Newtonsoft.Json

Public Class ReleaseOrders

    Dim helper As New IntegrationHelper
    Dim zodiacSoapController As New ZodiacSoapController
    Dim integrationController As New IntegrationController
    Dim timeout As Integer = CInt(ConfigurationManager.AppSettings("rest_client_timeout"))


    Public Function postLinerImportDeliveryOrder(zPartyId As String, zUserId As String, zPassword As String,
                                                 docNo As String, docType As String, docPrepDate As String,
                                                 docExpireDate As String, bolNum As String, boxLine As String,
                                                 containerList As String(), updateMode As String) As DataTable

        '* Variables *'
        Dim exemptionHelper As New ExemptionHelper
        Dim releaseOrder As New ReleaseOrders
        Dim email As New EmailController
        Dim requestMessage As String = ""
        Dim responseMessage As String = ""
        Dim docValidityDate As String = ""
        Dim client As RestClient
        Dim jsonUpdateBooking As String = ""
        Dim updateModeString As String = "EDO_" & updateMode.ToUpper.ToString()

        '* Return value *'
        Dim tableException As New DataTable()
        tableException.TableName = "postLinerImportDeliveryOrder"
        tableException.Columns.Add("retval", GetType(Integer))
        tableException.Columns.Add("retmsg", GetType(String))

        '* Validation block *'
        If Not integrationController.isDataValidated(zUserId, "user_id") Then : Return exemptionHelper.returnExemption("R1001") : End If
        If Not integrationController.isDataValidated(docPrepDate, "validity_date") Then : Return exemptionHelper.returnExemption("R1002") : End If
        If Not integrationController.isDataValidated(docExpireDate, "validity_date") Then : Return exemptionHelper.returnExemption("R1003") : End If

        Dim sent As Boolean = False
        Dim logged As Boolean = False


        Try

            '* Loop thru container and execute Rest call *'
            Dim containerUpdateURL As String = ConfigurationManager.AppSettings("zodiac_RESTFUL_url") & "/equipment/"

            Select Case updateMode
                Case "new"
                    jsonUpdateBooking = helper.readSoapMessageTemplate("../RESTMessage/UpdateContainerLinerBooking.json")
                Case "revalidate"
                    jsonUpdateBooking = helper.readSoapMessageTemplate("../RESTMessage/UpdateContainerLinerBooking.json")
                Case "replace"
                    jsonUpdateBooking = helper.readSoapMessageTemplate("../RESTMessage/UpdateContainerLinerBooking.json")
                Case "cancel"
                    jsonUpdateBooking = helper.readSoapMessageTemplate("../RESTMessage/UpdateContainerLinerAddLHCode.json")
            End Select


            Dim request As RestRequest

            'Authentication block
            Dim token As String = zodiacSoapController.getAuthToken(zUserId, zPassword, zPartyId)
            Global_asax.logger.Info("Token generated: " & token)


            '* Loop thru container and execute Rest call *'
            For i As Integer = 0 To (containerList.Length - 1)

                client = New RestClient(containerUpdateURL)
                client.Timeout = timeout
                client.ReadWriteTimeout = timeout

                'Execution block
                If integrationController.isDataValidated(token, "regex_valid_token_guid") Then

                    '* Rest client object *'
                    request = New RestRequest("update", Method.POST)
                    request.RequestFormat = DataFormat.Json
                    request.AddHeader("z.sessionToken", token)
                    request.AddHeader("z.bizunitcode", zPartyId)
                    request.AddHeader("z.user", zUserId)
                    request.AddHeader("z.ip", helper.getIPAddress)
                    request.AddHeader("z.locale", ConfigurationManager.AppSettings("zodiac_locale"))
                    request.AddHeader("cache-control", "no-cache")
                    docValidityDate = docExpireDate.Replace("-", "")
                    docValidityDate = Left(docValidityDate, 8)
                    docValidityDate = docValidityDate & "000000"

                    requestMessage = jsonUpdateBooking

                    Select Case updateMode
                        Case "new"
                            requestMessage = requestMessage.Replace("@containerId", containerList(i))
                            requestMessage = requestMessage.Replace("@doNumber", docNo)
                            requestMessage = requestMessage.Replace("@doValidity", docValidityDate)
                            requestMessage = requestMessage.Replace("@LHRemarks", updateModeString & "*" & docNo & "*" & docValidityDate & "*" & containerList(i))
                        Case "revalidate"
                            requestMessage = requestMessage.Replace("@containerId", containerList(i))
                            requestMessage = requestMessage.Replace("@doNumber", docNo)
                            requestMessage = requestMessage.Replace("@doValidity", docValidityDate)
                            requestMessage = requestMessage.Replace("@LHRemarks", updateModeString & "*" & docNo & "*" & docValidityDate & "*" & containerList(i))
                        Case "replace"
                            requestMessage = requestMessage.Replace("@containerId", containerList(i))
                            requestMessage = requestMessage.Replace("@doNumber", docNo)
                            requestMessage = requestMessage.Replace("@doValidity", docValidityDate)
                            requestMessage = requestMessage.Replace("@LHRemarks", updateModeString & "*" & docNo & "*" & docValidityDate & "*" & containerList(i))
                        Case "cancel"
                            requestMessage = requestMessage.Replace("@containerId", containerList(i))
                            requestMessage = requestMessage.Replace("@LHRemarks", updateModeString & "*" & docNo & "*" & docValidityDate & "*" & containerList(i))
                    End Select

                    request.AddParameter("application/json", requestMessage, ParameterType.RequestBody)

                    '* Client execute *'
                    Dim response As IRestResponse = client.Execute(request)
                    responseMessage = response.Content
                    Global_asax.logger.Info(String.Concat("DO Update <Request>: ", requestMessage, " , <Response>: ", responseMessage.ToString))

                    requestMessage = ""

                Else

                    Global_asax.logger.Error("Invalid user credentials.")
                    Return exemptionHelper.returnExemption("A1001")

                End If

            Next

            '* Update history *'
            logged = releaseOrder.logAuditBOL(bolNum, updateModeString, docNo, zUserId, My.Computer.Name.ToString(), docExpireDate)

            If email.IsEmailEnabled Then

                '* SMTP notify *'
                Dim recipients As String()
                Dim details(4) As String

                details(0) = updateMode
                details(1) = bolNum
                details(2) = String.Join(",", containerList)
                details(3) = docNo
                details(4) = docExpireDate

                recipients = releaseOrder.getRecipientDOUpdate(boxLine)
                Global_asax.logger.Info("SMTP recipients: " & String.Join(",", recipients))
                sent = email.SendEmail(EmailController.EmailTypes.DO_UPDATE, recipients, details)

            Else

                sent = False

            End If

            Global_asax.logger.Info("RESTFul postLinerImportDeliveryOrder debug info. Parameters: " &
                                    "{zPartyId As String, zUserId As String, zPassword As String, docNo As String, 
                                    docType As String, docPrepDate As String, docExpireDate As String, bolNum As String, boxLine As String,
                                    containerList As String(), updateMode As String}, Values: " &
                                    "{" & zPartyId & "," & zUserId & "," & zPassword & "," & docNo & "," & docType &
                                    "," & docPrepDate & "," & docExpireDate & "," & bolNum & "," & boxLine & "," &
                                    String.Join("|", containerList) & "," & updateMode & "} Response: " & responseMessage)

            tableException.Rows.Add(1, String.Concat(updateModeString, " is successful. Logged: ", logged.ToString, " Notify SMTP: ", sent.ToString))

        Catch ex As Exception
            ''* Exemption block *'
            tableException.Rows.Add(-1, ex.ToString)
            Global_asax.logger.Error("Post Import Delivery Order encountered exception.", ex)

        End Try

        Return tableException

    End Function


    Public Function logAuditBOL(bol As String, activity As String, reference As String, userId As String, machineId As String, validityDate As String) As Boolean

        Dim returnTable As DataTable
        integrationController.getConnectionString("cwa")
        returnTable = integrationController.getTable("logAuditItem", CommandType.StoredProcedure,
                                       New SqlClient.SqlParameter("@bol", bol),
                                       New SqlClient.SqlParameter("@activity", activity),
                                       New SqlClient.SqlParameter("@reference", reference),
                                       New SqlClient.SqlParameter("@userId", userId),
                                       New SqlClient.SqlParameter("@machineId", machineId),
                                       New SqlClient.SqlParameter("@validityDate", validityDate))
        Return True

    End Function


    Public Function getAuditBOL(bol As String) As DataTable
        Dim returnTable As New DataTable
        integrationController.getConnectionString("cwa")
        returnTable = integrationController.getTable("getBOLAuditDetails", CommandType.StoredProcedure,
                                       New SqlClient.SqlParameter("@bol", bol))
        returnTable.TableName = "getAuditBOL"
        Return returnTable
    End Function

    Public Function getRecipientDOUpdate(line As String) As String()

        Dim returnTable As New DataTable
        integrationController.getConnectionString("cwa")
        returnTable = integrationController.getTable("getEmailRecipientOnDOUpdate", CommandType.StoredProcedure,
                                       New SqlClient.SqlParameter("@lineCode", line))
        returnTable.TableName = "getRecipientDOUpdate"

        Dim rows As DataRow() = returnTable.Select()
        Dim array As String() = rows.[Select](Function(row) row("EmailAddress").ToString()).ToArray()
        Return array

    End Function


End Class
