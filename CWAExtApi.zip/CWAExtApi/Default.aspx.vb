﻿Imports log4net
Public Class _Default
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            Global_asax.logger.Info("Default page loaded successfully.")
        Catch ex As Exception

        End Try
    End Sub

End Class